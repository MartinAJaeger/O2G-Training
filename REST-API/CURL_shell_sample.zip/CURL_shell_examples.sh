#!/bin/bash
#######################################################################################################################
#TITLE           :restCLI.sh
#DESCRIPTION     :Bash script for OT REST API service tests.
#AUTHOR		 :P.Olivier
#date            :20140901
#version         :0.2    
#usage		 :./restCLI.sh

#HISTORY
########
#0.2 [20141119]	: Routing Forward / Overflow
#0.1 [20140901] : First draft release
#######################################################################################################################

declare DIR="$( cd "$( dirname "$0" )" && pwd )"
declare -r LOGS=${DIR}/logs

#cURL Options
# See 
declare -r CURL_OPT="-L -k -v -i -s -S";


GREEN="\\033[1;32m" 
NORMAL="\\033[0;39m" 
RED="\\033[1;31m" 
BLUE="\\033[1;34m" 
WHITE="\\033[0;02m" 
YELLOW="\\033[1;33m" 

###############################################################################
function help() {

	echo -e "$GREEN"
	echo "************* REST CLI HELP MENU *********************"
	echo -e "$0 authent <login> <pwd>                    : Authenticate with the given credentials."
	echo -e "$0 openSession [<appName>]                  : Open session with given appName (MYIC_DESKPHONE by default)."
	echo -e "$0 login <login> <pwd> [<appName>]          : Authenticate AND open session."
	echo -e "$0 closeSession                             : Close session."
	echo -e "$0 subscribe                                : Subscribe to events and start chunk (USE ANOTHER SHELL !)."
	echo "------------------- USER ----------------------------"
	echo -e "$0 getUserInfo                              : Get User Info."
	echo -e "$0 getUserPref                              : Get User Preferences."
	echo -e "$0 setTelPrefs <mode>                       : Set Telephony Preferences (CLIR)."
	echo "------------------- COMLOG ----------------------------"
	echo -e "$0 getComLog                                : Get whole comlog."
	echo -e "$0 delComLog                                : Delete the whole comlog."
	echo -e "$0 delComRecord <recordId>                  : Delete the given comlog record."
	echo -e "$0 ackComRecord <recordId>                  : Acknowledge the given comlog record."
	echo "------------------- ROUTING ---------------------------"
	echo -e "$0 getRoutCapa                              : Get Routing capabilities."
	echo -e "$0 getRoutState                             : Get Routing state."
	echo -e "$0 applyRoutProfile <profileId>             : Apply Routing profile."
	echo -e "$0 setForwardToUser <phoneNumber>           : Set Forward to User."
	echo -e "$0 cancelForwardToUser                      : Cancel Forward to User."
	echo -e "$0 setForwardToVM                           : Set Forward to VM."
	echo -e "$0 cancelForwardToVM                        : Cancel Forward to VM."
	echo -e "$0 setOverflow <ovfType> <dest> [phoneNb]   : Set Overflow."
	echo -e "$0 cancelOverflow                           : Cancel Overflow."
	echo "******************************************************"
	echo -e "$NORMAL"
}

###############################################################################
function setLog() {

	if [ ! -d ${LOGS} ]; then
		mkdir -p ${LOGS}
	fi
	echo -e "$YELLOW" "*** LOGS will be found in ${LOGS} ***" "$NORMAL"
}

###############################################################################
function parseCookieFile() {

	while read -r a b c d e cookie_name cookie_value
	do
		if [ "$cookie_name" == "AlcUserId" ]; then
			echo "export REST_FWKID=$cookie_value" >> vars.sh
		fi
		#echo "Name = $cookie_name Value = $cookie_value"
	done < ${REST_LOGIN}_cookies.txt
}

###############################################################################
function authent() {

	setLog
	if [ "$#" -ne 2 ]; then
    		echo -e "$RED" "usage: $0 authent <login> <GUI pwd>" "$NORMAL"
		sleep 1
		exit 1
	fi
	echo "export REST_HOST=`hostname`" > vars.sh
	echo "export REST_LOGIN=$1" >> vars.sh
	echo "export REST_PWD=$2" >> vars.sh
	. vars.sh

	echo -e "\n\r$YELLOW" "Will try authenticate with LOGIN=${REST_LOGIN}, PWD=${REST_PWD}, HOST=${REST_HOST}" "$NORMAL"
	curl ${CURL_OPT} -c ${REST_LOGIN}_cookies.txt -b ${REST_LOGIN}_cookies.txt -u ${REST_LOGIN}:${REST_PWD} \
	https://${REST_HOST}/api/rest/authenticate?version=1.0 &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}_authent.log
	echo
	parseCookieFile
}

###############################################################################
function openSession() {

	if [ "$#" -eq 1 ]; then
    		echo "export REST_APPNAME=$1" >> vars.sh
	else
		echo "export REST_APPNAME=MYIC_DESKPHONE" >> vars.sh
	fi 
	. vars.sh

	echo -e "\n\r$YELLOW" "Opening session with ${REST_APPNAME}" "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -d "{\"applicationName\": \"${REST_APPNAME}\"}" -H "Content-Type: application/json" \
	https://${REST_HOST}/api/rest/1.0/sessions &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__session.log
	echo
}

###############################################################################
function login() {

	setLog
	authent $1 $2
	openSession $3
}

###############################################################################
function closeSession() {

	. vars.sh
	echo -e "\n\r$YELLOW" "Closing session." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -X DELETE -H "Content-Type: application/json" \
	https://${REST_HOST}/api/rest/1.0/sessions &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__sessionDel.log
	echo
}

###############################################################################
function subscribe() {

	. vars.sh
	echo -e "\n\r$YELLOW" "Subscription to HTTP chunk." "$NORMAL"
	SELECTORS="{\"ids\":[\"${REST_LOGIN}\"],\"names\":[\"telephony\"]},\
{\"ids\":[\"${REST_LOGIN}\"],\"names\":[\"unifiedComLog\"]},\
{\"ids\":[\"${REST_LOGIN}\"],\"names\":[\"eventSummary\"]},\
{\"ids\":[\"${REST_LOGIN}\"],\"names\":[\"routingManagement\"]},\
{\"ids\":[\"${REST_LOGIN}\"],\"names\":[\"user\"]},\
{\"ids\":[\"${REST_LOGIN}\"],\"names\":[\"messaging\"]}"

	echo "Selector: $SELECTORS";

	SUBSCR="{\"filter\":{\"selectors\":[$SELECTORS]},\"mode\":\"CHUNK\",\"format\":\"JSON\",\"sessionId\":\"${REST_FWKID}\",\"version\":\"1.0\",\"timeout\":0,\"keepalive\":0,\"init\":false}"

	echo "Subscription: $SUBSCR";

	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -d $SUBSCR -H "Content-Type: application/json" \
	https://${REST_HOST}/api/rest/1.0/subscriptions &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__subscription.log

	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -X POST -H "Transfer-Encoding: chunked" \
	https://${REST_HOST}:8016/OTEvents?subscriptionId=${REST_FWKID}
	
}

#######################################################################################################################
#                                                      USER                   
#######################################################################################################################
function getUserInfo() {

	. vars.sh
	echo -e "\n\r$YELLOW" "Getting User Info." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -H "Content-Type: application/json" \
	https://${REST_HOST}/api/rest/1.0/users/${REST_LOGIN} &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__getUserInfo.log
	echo
}

#######################################################################################################################
function getUserPref() {

	. vars.sh
	echo -e "\n\r$YELLOW" "Getting User Preferences." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -H "Content-Type: application/json" \
	https://${REST_HOST}/api/rest/1.0/users/${REST_LOGIN}/preferences &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__getUserPref.log
	echo
}

#######################################################################################################################
function setTelPref() {

	if [ "$#" -lt 1 ]; then
    		echo -e "$RED" "usage: $0 setTelPref <clirMode>" "$NORMAL"
		sleep 1
		exit 1
	fi
	. vars.sh
	echo -e "\n\r$YELLOW" "Set Telephony Preferences." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -X POST -d "{\"clirMode\": \"$1\"}"  -H "Content-Type: application/json" \
	-d "{\"recordIds\": [$1]}" \
	https://${REST_HOST}/api/rest/1.0/users/${REST_LOGIN}/preferences/telephony &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__setClirMode.log
	echo
}
#######################################################################################################################
#                                                      COMLOG
#######################################################################################################################
function getComLog() {

	. vars.sh
	echo -e "\n\r$YELLOW" "Getting ComLog." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -H "Content-Type: application/json" \
	https://${REST_HOST}/api/rest/1.0/comlog/records &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__getComLog.log
	echo
}

#######################################################################################################################
function delComLog() {

	. vars.sh
	echo -e "\n\r$YELLOW" "Deleting ComLog." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -X DELETE -H "Content-Type: application/json" \
	https://${REST_HOST}/api/rest/1.0/comlog/records &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__delComLog.log
	echo
}

#######################################################################################################################
function delComRecord() {

	if [ "$#" -ne 1 ]; then
    		echo -e "$RED" "usage: $0 delComRecord <recordId>" "$NORMAL"
		sleep 1
		exit 1
	fi
	. vars.sh
	echo -e "\n\r$YELLOW" "Deleting ComLog Record." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -X DELETE -H "Content-Type: application/json" \
	https://${REST_HOST}/api/rest/1.0/comlog/records/$1 &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__delComRecord.log
	echo
}

#######################################################################################################################
function ackComRecord() {

	if [ "$#" -lt 1 ]; then
    		echo -e "$RED" "usage: $0 ackComRecord <recordId>" "$NORMAL"
		sleep 1
		exit 1
	fi
	. vars.sh
	echo -e "\n\r$YELLOW" "Acknowledge ComLog Record." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -X PUT -H "Content-Type: application/json" \
	-d "{\"recordIds\": [$1]}" \
	https://${REST_HOST}/api/rest/1.0/comlog/records?acknowledge=true &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__ackComRecord.log
	echo
}

######################################################################################################################################
#                                                     ROUTING
######################################################################################################################################
function getRoutCapa() {

	. vars.sh
	echo -e "\n\r$YELLOW" "Getting Routing capabilities." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -H "Content-Type: application/json" \
	https://${REST_HOST}/api/rest/1.0/routing &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__getRoutCapa.log
	echo
}

######################################################################################################################################
function getRoutState() {

	. vars.sh
	echo -e "\n\r$YELLOW" "Getting Routing state." "$NORMAL"
	curl -L -k -i -s -w '%{http_code}' -b ${REST_LOGIN}_cookies.txt -H "Content-Type: application/json" \
	https://${REST_HOST}/api/rest/1.0/routing/state &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__getRoutState.log
	echo 

}
#############################################################################################################################
function applyRoutProfile() {

	if [ "$#" -ne 1 ]; then
    		echo -e "$RED" "usage: $0 ackComRecord <recordId>" "$NORMAL"
		sleep 1
		exit 1
	fi
	. vars.sh
	echo -e "\n\r$YELLOW" "Apply routing profile." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -X PUT -H "Content-Type: application/json" -d "{}" \
	https://${REST_HOST}/api/rest/1.0/routing/profiles/$1 &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__applyRoutProfile.log
	echo
}

#############################################################################################################################
function setForwardToUser() {

	if [ "$#" -ne 1 ]; then
    		echo -e "$RED" "usage: $0 setForwardToUser <phoneNumber>" "$NORMAL"
		sleep 1
		exit 1
	fi
	. vars.sh
	echo -e "\n\r$YELLOW" "Set Forward to User." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -X POST -H "Content-Type: application/json" \
	-d "{\"forwardRoutes\":[{\"destinations\":[{\"type\":\"USER\",\"number\":\"$1\",\"selected\":true}]}],\"requestId\":\"RestCLI_script\"}" \
	https://${REST_HOST}/api/rest/1.0/routing &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__setForwardToUser.log
	echo
}

#############################################################################################################################
function cancelForwardToUser() {

	. vars.sh
	echo -e "\n\r$YELLOW" "Cancel Forward to User." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -X POST -H "Content-Type: application/json" \
	-d "{\"forwardRoutes\":[{\"destinations\":[{\"type\":\"USER\",\"selected\":false}]}],\"requestId\":\"RestCLI_script\"}" \
	https://${REST_HOST}/api/rest/1.0/routing &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__cancelForwardToUser.log
	echo
}

#############################################################################################################################
function setForwardToVM() {

	. vars.sh
	echo -e "\n\r$YELLOW" "Set Forward to VM." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -X POST -H "Content-Type: application/json" \
	-d "{\"forwardRoutes\":[{\"destinations\":[{\"type\":\"VOICEMAIL\",\"selected\":true}]}],\"requestId\":\"RestCLI_script\"}" \
	https://${REST_HOST}/api/rest/1.0/routing &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__setForwardToVM.log
	echo
}

#############################################################################################################################
function cancelForwardToVM() {

	. vars.sh
	echo -e "\n\r$YELLOW" "Cancel Forward to VM." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -X POST -H "Content-Type: application/json" \
	-d "{\"forwardRoutes\":[{\"destinations\":[{\"type\":\"VOICEMAIL\",\"selected\":false}]}],\"requestId\":\"RestCLI_script\"}" \
	https://${REST_HOST}/api/rest/1.0/routing &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__cancelForwardToVM.log
	echo
}

#############################################################################################################################
function setOverflow() {

	if [ "$#" -ne 3 ]; then
    		echo -e "$RED" "usage: $0 setOverflow <ovfType> <dest> [phoneNb]" "$NORMAL"
		sleep 1
		exit 1
	fi
	. vars.sh
	echo -e "\n\r$YELLOW" "Set Overflow $1 $2 $3." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -X POST -H "Content-Type: application/json" \
	-d "{\"overflowRoutes\":[{\"destinations\":[{\"type\":\"$2\",\"number\":\"$3\",\"selected\":true}],\"overflowType\":\"$1\"}],\"requestId\":\"RestCLI_script\"}" \
	https://${REST_HOST}/api/rest/1.0/routing/overflowroute &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__setOverflow.log
	echo
}

#############################################################################################################################
function cancelOverflow() {

	if [ "$#" -ne 3 ]; then
    		echo -e "$RED" "usage: $0 cancelOverflow" "$NORMAL"
		sleep 1
		exit 1
	fi
	. vars.sh
	echo -e "\n\r$YELLOW" "Cancel Overflow." "$NORMAL"
	curl ${CURL_OPT} -b ${REST_LOGIN}_cookies.txt -X DELETE -H "Content-Type: application/json" \	
	https://${REST_HOST}/api/rest/1.0/routing/overflowroute &> /dev/stdout | tee -a ${LOGS}/${REST_LOGIN}__cancelOverflow.log
	echo
}

#############################################################################################################################
#                                                          Main                                                             #
#############################################################################################################################

. vars.sh
# This script must be run as "root"
if [ "$USER" != "root" ]; then
	echo -e "$RED" "This script must be run as root" "$NORMAL"
	sleep 1
	exit 1
fi

#echo "main args: $# $@"
if [ "$#" -eq 0 ]; then
	echo -e "$RED" "usage: $0 <action> [params]." "$NORMAL"
	help
	sleep 1
	exit 1
fi
$@
#####################################################################

